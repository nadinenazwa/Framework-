<?php

use Illuminate\Support\Facades\Route;
// Import yang lama (hapus atau ganti): use App\Http\Controllers\PublicController;

// Import yang baru:
use App\Http\Controllers\Site\SiteController; 

/*
|--------------------------------------------------------------------------
| Public Web Routes
|--------------------------------------------------------------------------
*/

// Home (index.php)
Route::get('/', [SiteController::class, 'index'])->name('home');

// Struktur Organisasi (struktur.php)
Route::get('/struktur', [SiteController::class, 'strukturOrganisasi'])->name('struktur');

// Layanan Umum (layanan.php)
Route::get('/layanan', [SiteController::class, 'layananUmum'])->name('layanan');

// Visi Misi & Tujuan (visi.php)
Route::get('/visimisi', [SiteController::class, 'visiMisi'])->name('visimisi');

// Login
Route::get('/login', [SiteController::class, 'login'])->name('login');